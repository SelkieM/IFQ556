﻿using System;

using static System.Console;

namespace BookStore

{

    public class Book
    {
        private string categoryCodes;
        private string inputBookId;
        private string bookTitle;
        private int numOfPages;
        private double price;

        public Book()
        {

        }

        public Book(string Id, int pages, double price, string booktitle)
        {
            InputBookId = Id;
            NumOfPages = pages;
            Price = price;
            bookTitle = booktitle;
        }
        public string InputBookId
        {
            get { return inputBookId; }
            set { inputBookId = value; }
        }

        public string BookTitle
        {
            get { return bookTitle; }
            set { bookTitle = value; }
        }
        public int NumOfPages
        {
            get { return numOfPages; }
            set { numOfPages = value; }
        }
        public double Price
        {
            get { return price; }
            set { price = value; }
        }

        
        public override string ToString()
        {
            return "Information of all books:" + bookTitle + numOfPages + Price;

        }
    }
}
            

       
    


     
        

        
            
      
    

    
        
    