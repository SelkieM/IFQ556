﻿using System;

using static System.Console;

namespace BookStore

{


    class Program

    {

        static void Main(string[] args)

        {

            int count = InputValue(1, 30);
           
            Book[] books = new Book[count];

            GetBookData(count, books);
            DisplayAllBooks(books);

            GetLists(count, books);
        }


        public static int InputValue(int min, int max)
        {
            
            int val;
            Console.WriteLine($"Enter a number between {min}, {max}:");

            do
            {
                val = Convert.ToInt32(Console.ReadLine());
                if (val > max || val < min)
                    Console.WriteLine("Please enter number within the range...");
            }
            while (val > max || val < min);


            return val;
        }



        public static bool IsValid(string id)
        {

           
            if (id.Length != 5)
                return false;
            
            char c1 = id[0];
            char c2 = id[1];

            if (!char.IsUpper(c1) || !char.IsUpper(c2))
                return false;
            
            char c3 = id[2];
            char c4 = id[3];
            char c5 = id[4];

            if (!char.IsNumber(c3) || !char.IsNumber(c4) || !char.IsNumber(c5))
                return false;

            return true;
        }

        public static string InputBookId()
        {
            string id = "";
            while (true)
            {
                Console.Write("Book Id>> ");
                id = Console.ReadLine();

                if (IsValid(id))
                    break;

                Console.WriteLine("Invalid book Id");
            }

            char c1 = id[0];
            char c2 = id[1];
            string firstTwo = string.Concat(c1, c2);
            
           if ((firstTwo.CompareTo("CS") != 0) && (firstTwo.CompareTo("IS") != 0) && (firstTwo.CompareTo("SE") != 0) && (firstTwo.CompareTo("SO") != 0))

           {
                firstTwo = "MI";
                char c3 = id[2];
                char c4 = id[3];
                char c5 = id[4];
                id = string.Concat(firstTwo, c3, c4, c5);

           }
           
            return id;
        }

        private static void GetBookData(int num, Book[] books)
        {
            
            for (int i = 0; i < num; ++i)
            {
                Console.WriteLine("Enter book title");
                string title = Console.ReadLine();

                Console.WriteLine("Enter a book Id which starts with a category code and ends in 3 digits>>");
                Console.WriteLine("category codes are:");
                CategoryCodes();

                string bookId = "";
                do
                {
                    bookId = InputBookId();
                } while (IsValid(bookId) == false);


                Console.WriteLine("Enter book price");
                double dollars = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Enter book pages");
                int pages = Convert.ToInt32(Console.ReadLine());


                Book myBook = new Book(bookId, pages, dollars, title);
               
                books[i] = myBook;
            }



        }

        public static void DisplayAllBooks(Book[] books)
        {
            for(var i = 0; i < books.Length; i++)
            {
                Console.WriteLine(books[i]);
            }
        }


        private static void GetLists(int num, Book[] books)
        {
            Console.WriteLine("category codes are:");
            CategoryCodes();


            string[] codes = { "CS", "IS", "SE", "SO", "MI" };

            Console.Write("Enter book category code: ");            
            string code = Console.ReadLine();
            while(!codes.Contains(code))
            {
                Console.WriteLine("Category code is invalid. please input again");
                code = Console.ReadLine();
            }

            for(var i = 0; i < num; i++)
            {

                string firstTwo = books[i].InputBookId.Substring(0, 2);
                if( firstTwo.Equals(code) )
                {
                    Console.WriteLine(books[i]);
                }
            }
        }

        private static void CategoryCodes()
        {
            string[] codes = { "CS", "IS", "SE", "SO", "MI" };
            string[] names = { "Computer Sciece", "Infomration Systems", "Security", "Society", "Miscellanous" };

            string[] result = new string[codes.Length];
            for (int i = 0; i < codes.Length; i++)
            {
                result[i] = codes[i] + " " + names[i];
                Console.WriteLine(result[i]);
            }
        }

    }
}

       


