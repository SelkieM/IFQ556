﻿using System;

using static System.Console;


namespace Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            double litres = InputValue("The number of litres of fuel");
            string id = InputFuelType();
            double cost = InputValue("Cost of fuel");

            double totalCost = CalculateTotalCost(litres, cost);

            DisplayResult(id, litres, cost, totalCost);

            Console.ReadLine();
        }

        public static bool IsValid(string id)
        {

            if (id.Length != 3)
                return false;


            char c1 = id[0];
            if (c1 < 'A' || c1 > 'Z')
                return false;


            char c2 = id[1];
            char c3 = id[2];
            if (c2 < '0' || c2 > '9' || c3 < '0' || c3 > '9')
                return false;

            return true;
        }

        public static string InputFuelType()
        {
            string id = "";
            while (true)
            {
                Console.Write("Fuel type: ");
                id = Console.ReadLine();

                if (IsValid(id))
                    break;

                Console.WriteLine("Invalid Fuel Type");
            }

            return id;
        }

        public static double InputValue(string label)
        {
            double val = 0;

            while (true)
            {
                Console.Write(label + ": ");
                if (double.TryParse(Console.ReadLine(), out val))
                {
                    if (val > 0)
                        break;
                }

                Console.WriteLine("Number should be positive value, Please try again...");
            }

            return val;
        }

        public static double CalculateTotalCost(double litres, double cost)
        {
            return litres * cost;
        }

        public static void DisplayResult(string id, double litres, double cost, double totalCost)
        {
            // output
            Console.WriteLine(String.Format("\nThe number of litres of fuel: {0:0.00}", litres));
            Console.WriteLine(String.Format("Fuel type: {0}", id));
            Console.WriteLine(String.Format("Cost of fuel: ${0}", cost));
            Console.WriteLine(String.Format("Total cost of fuel: ${0:0.00}", totalCost));
        }
    }
}

